<?php
$bot_token = "5979773275:AAFKWjQGcWIeiYTgObcD-e2_IKHqKDnLH_g"; /* bot token */
$chat_id = "240837047"; /* chatid */

?>